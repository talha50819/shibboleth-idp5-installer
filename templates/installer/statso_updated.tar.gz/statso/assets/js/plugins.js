var Plugins=function(){var g=function(){$.browser={};(function(){$.browser.msie=false;$.browser.version=0;if(navigator.userAgent.match(/MSIE ([0-9]+)\./)){$.browser.msie=true;$.browser.version=RegExp.$1}})()};
var i=function(){if($.fn.daterangepicker){$(".range").daterangepicker({
	startDate:moment().subtract("days",29),
	endDate:moment(),
	showDropdowns:true,
	showWeekNumbers:true,
	timePicker:false,
	timePickerIncrement:1,
	timePicker12Hour:true,
	ranges:{Today:[moment(),moment()],
	Yesterday:[moment().subtract("days",1),moment().subtract("days",1)],
	"Last 7 Days":[moment().subtract("days",6),moment()],"Last 30 Days":[moment().subtract("days",29),
	moment()],"This Month":[moment().startOf("month"),moment().endOf("month")],
	"Last Month":[moment().subtract("month",1).startOf("month"),moment().subtract("month",1).endOf("month")]},
	opens:"left",buttonClasses:["btn btn-default"],applyClass:"btn-sm btn-primary",
	cancelClass:"btn-sm",
	format:"MM/DD/YYYY",
	separator:" to ",
	locale:{applyLabel:"Submit",fromLabel:"From",toLabel:"To",customRangeLabel:"Custom Range",
	daysOfWeek:["Su","Mo","Tu","We","Th","Fr","Sa"],
	monthNames:["January","February","March","April","May","June","July","August","September","October","November","December"],
	firstDay:1}},function(q,o){
		startdate=q.format('YYYY-MM-DD');
		enddate=o.format('YYYY-MM-DD');
	
	var p=q.format("MMMM D, YYYY")+" - "+o.format("MMMM D, YYYY");
	$.ajax({
            url: "getcontent2.php",
            type: "POST",
            data:'start='+startdate+'&end='+enddate,
            success: function(result){ 

            	function isJson(str) {
             try {
                 JSON.parse(str);
             } catch (e) {
                 return false;
             }
             return true;
              } 
              if(isJson(result)==true){
            document.getElementById("stats").style.display = "block";
            var obj=JSON.parse(result);
            document.getElementById("logintotal").innerHTML = obj.count_total_logins;
            document.getElementById("rptotal").innerHTML =  obj.count_unique_rp;
            document.getElementById("uidstotal").innerHTML = obj.count_unique_user; 
            var rpstats=[];
            var userstats=[];
            Object.keys(obj.count_per_rp).forEach(function(n,i){
            var v = obj.count_per_rp[n];
                 rpstats.push({ 
                 rp : n,
                 count : v,
                }); 
            });
            Object.keys(obj.count_per_user).forEach(function(n,i){
            var v = obj.count_per_user[n];
                 userstats.push({ 
                 user : n,
                 count : v,               
                });          
              });

    var chart = AmCharts.makeChart("chartdiv", {
  "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
   "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "0%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "50%",
      "height": "300%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": rpstats,
  "valueField": "count",
  "titleField": "rp",
  "depth3D": 10,
  "angle": 30,
  "outlineAlpha": 0.1,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
    "fileName": "publisherstats", 
  }
});

chart.addListener("init", handleInit);

chart.addListener("rollOverSlice", function(e) {
  handleRollOver(e);
});
var chart = AmCharts.makeChart("chartdiv1", {
    "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
   "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "0%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "200%",
      "height": "200%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": userstats,
  "valueField": "count",
  "titleField": "user",
  "outlineAlpha": 0.1,
  "depth3D": 15,
  "angle": 30,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
     "fileName": "userstats", 
  }
});

chart.addListener("init", handleInit);

chart.addListener("rollOverSlice", function(e) {
  handleRollOver(e);
});

function handleInit(){
  chart.legend.addListener("rollOverItem", handleRollOver);
}

function handleRollOver(e){
  var wedge = e.dataItem.wedge.node;
  wedge.parentNode.appendChild(wedge);
}
 $('#example').DataTable( {
           
             "destroy": true,
             "data":obj.logs,
             "columns": [
            { "data": "datetime" },
            { "data": "user" },
            { "data": "rp" },         
        ],'buttons':['pdf']});

              	/*if(w.hasClass("table-checkable"))
              	{$.extend(true,y,{
              		aaData:obj.logs,
              		aoColumnDefs:[{
									"mData": "user",
									"aTargets": [0]
									},
									{
									"mData": "user",
									"aTargets": [1]
									},
									{
									"mData": "user",
									"aTargets": [2]
									}
									]})}*/

              }else
            {
                alert(result);
            }
          


          },
             error:function(result,status){
               alert("Error!!"+ status + " Plese Try again..");
            }
        });
	App.blockUI($("#content"));
	setTimeout(function(){App.unblockUI($("#content"));
	noty({text:"<strong>Dashboard updated to "+p+".</strong>",type:"success",timeout:1000})},1000);$(".range span").html(p)});
   $(".range span").html(moment().subtract("days",29).format("MMMM D, YYYY")+" - "+moment().format("MMMM D, YYYY"))}};
   var k=function(){if($.fn.sparkline){$.extend(true,$.fn.sparkline.defaults,{line:{highlightSpotColor:App.getLayoutColorCode("green"),highlightLineColor:App.getLayoutColorCode("red")},bar:{barColor:App.getLayoutColorCode("blue"),negBarColor:App.getLayoutColorCode("red"),barWidth:5,barSpacing:2},tristate:{posBarColor:App.getLayoutColorCode("green"),negBarColor:App.getLayoutColorCode("red")},box:{medianColor:App.getLayoutColorCode("red")}});$(window).resize(function(){$.sparkline_display_visible()}).resize();$(".statbox-sparkline").each(function(){$(this).sparkline("html",Plugins.getSparklineStatboxDefaults())})}};var l=function(){$.extend(true,$.fn.tooltip.defaults,{container:"body"});$(".bs-tooltip").tooltip({container:"body"});$(".bs-focus-tooltip").tooltip({trigger:"focus",container:"body"})};var h=function(){$(".bs-popover").popover()};var d=function(){if($.noty){$.extend(true,$.noty.defaults,{type:"alert",timeout:false,maxVisible:5,animation:{open:{height:"toggle"},close:{height:"toggle"},easing:"swing",speed:200}})}};var c=function(){if($.easyPieChart){$.extend(true,$.easyPieChart.defaultOptions,{lineCap:"butt",animate:500,barColor:App.getLayoutColorCode("blue")});$(".circular-chart").easyPieChart({size:110,lineWidth:10})}};var m=function(){};var j={colors:[App.getLayoutColorCode("blue"),App.getLayoutColorCode("red"),App.getLayoutColorCode("green"),App.getLayoutColorCode("purple"),App.getLayoutColorCode("grey"),App.getLayoutColorCode("yellow")],legend:{show:true,labelBoxBorderColor:"",backgroundOpacity:0.95},series:{points:{show:false,radius:3,lineWidth:2,fill:true,fillColor:"#ffffff",symbol:"circle"},lines:{show:true,lineWidth:2,fill:false,fillColor:{colors:[{opacity:0.4},{opacity:0.1}]},},bars:{lineWidth:1,barWidth:1,fill:true,fillColor:{colors:[{opacity:0.7},{opacity:1}]},align:"left",horizontal:false},pie:{show:false,radius:1,label:{show:false,radius:2/3,formatter:function(o,p){return'<div style="font-size:8pt;text-align:center;padding:2px;color:white;text-shadow: 0 1px 0 rgba(0, 0, 0, 0.6);">'+o+"<br/>"+Math.round(p.percent)+"%</div>"},threshold:0.1}},shadowSize:0},grid:{show:true,borderColor:"#efefef",tickColor:"rgba(0,0,0,0.06)",labelMargin:10,axisMargin:8,borderWidth:0,minBorderMargin:10,mouseActiveRadius:5},tooltipOpts:{defaultTheme:false},selection:{color:App.getLayoutColorCode("blue")}};var b={colors:["#ffffff"],legend:{show:false,backgroundOpacity:0},series:{points:{}},grid:{tickColor:"rgba(255, 255, 255, 0.1)",color:"#ffffff",},shadowSize:1};var f=function(){if($.fn.knob){$(".knob").knob();$(".knob").each(function(){if(typeof $(this).attr("data-fgColor")=="undefined"){$(this).trigger("configure",{fgColor:App.getLayoutColorCode("blue"),inputColor:App.getLayoutColorCode("blue")})}})}};var n={type:"bar",height:"19px",zeroAxis:false,barWidth:"4px",barSpacing:"1px",barColor:"#fff"};var e=function(){if($.fn.colorpicker){$(".bs-colorpicker").colorpicker()}};var a=function(){if($.fn.template){$.extend(true,$.fn.template.defaults,{})}};return{init:function(){g();i();k();l();h();d();m();c();f();e()},getFlotDefaults:function(){return j},getFlotWidgetDefaults:function(){return $.extend(true,{},Plugins.getFlotDefaults(),b)},getSparklineStatboxDefaults:function(){return n}}}();
