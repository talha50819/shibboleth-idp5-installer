-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2020 at 11:01 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stats`
--

-- --------------------------------------------------------

--
-- Table structure for table `idpdetails`
--

CREATE TABLE `idpdetails` (
  `id` bigint(20) NOT NULL,
  `idpname` varchar(80) NOT NULL,
  `entityid` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `spdetails`
--

CREATE TABLE `spdetails` (
  `id` bigint(20) NOT NULL,
  `spname` varchar(80) NOT NULL,
  `entityid` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spdetails`
--

INSERT INTO `spdetails` (`id`, `spname`, `entityid`) VALUES
(1, 'ACS Publications', 'https://pubs.acs.org/shibboleth'),
(2, 'Annual Reviews', 'https://www.annualreviews.org/shibboleth'),
(3, 'Association for Computing Machinery', 'https://dl.acm.org/shibboleth'),
(4, 'Association for Computing Machinery - Development', 'https://dldev.acm.org/shibboleth'),
(5, 'Cambridge Journals Online', 'https://shibboleth.cambridge.org/shibboleth-sp'),
(6, 'Emerald Insight', 'https://www.emeraldinsight.com/shibboleth'),
(7, 'HighWire Press', 'https://shibboleth2sp.tf.semcs.net/shibboleth'),
(8, 'IEEE - XploreUAT SP - Test', 'https://xploreuat.ieee.org/shibboleth-sp'),
(9, 'IEEE XploreDigital Library', 'https://ieeexplore.ieee.org/shibboleth-sp'),
(10, 'INFLIBNET SP', 'https://infonet.inflibnet.ac.in/shibboleth'),
(11, 'Wiley Online Library', 'https://sp.onlinelibrary.wiley.com/shibboleth'),
(12, 'Palgrave Connect', 'https://secure.palgraveconnect.com/shibboleth'),
(13, 'Nature Publishing Group', 'https://secure.nature.com/shibboleth'),
(14, 'Nature Publishing Group (platformdev)', 'https://platformdev-secure.nature.com/shibboleth'),
(15, 'Nature Publishing Group (staging)', 'https://staging-secure.nature.com/shibboleth'),
(16, 'Nature Publishing Group (test)', 'https://test-secure.nature.com/shibboleth'),
(17, 'Palgrave Journals (platformdev)', 'https://platformdev-secure.palgrave-journals.com/shibboleth'),
(18, 'Palgrave Macmillan- Stagging', 'https://staging-secure.palgraveconnect.com/shibboleth'),
(19, 'Palgrave Connect Test', 'https://test-secure.palgraveconnect.com/shibboleth'),
(20, 'Royal Society of Chemistry', 'https://shibdev.rsc.org/shibboleth'),
(21, 'Springer Nature', 'https://fsso.springer.com'),
(22, 'Taylor & Francis Online', 'https://www.tandfonline.com/shibboleth'),
(23, 'Thomson Reuters', 'https://sp.tshhosting.com/shibboleth'),
(24, 'JSTOR', 'https://shibboleth2sp.jstor.org/shibboleth'),
(25, 'Institute Of Physics', 'https://ticket.iop.org/shibboleth'),
(26, 'ebsco', 'http://shibboleth.ebscohost.com');

-- --------------------------------------------------------

--
-- Table structure for table `stateinfo`
--

CREATE TABLE `stateinfo` (
  `id` bigint(65) NOT NULL,
  `code` varchar(65) NOT NULL,
  `state` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stateinfo`
--

INSERT INTO `stateinfo` (`id`, `code`, `state`) VALUES
(1, 'IN-AN', 'Andaman and Nicobar Islands'),
(2, 'IN-AP', 'Andhra Pradesh'),
(3, 'IN-AR', 'Arunachal Pradesh'),
(4, 'IN-AS', 'Assam'),
(5, 'IN-BR', 'Bihar'),
(6, 'IN-CH', 'Chandigarh'),
(7, 'IN-CT', 'Chhattisgarh'),
(8, 'IN-DD', 'Daman and Diu'),
(9, 'IN-DL', 'Delhi'),
(10, 'IN-DN', 'Dadra and Nagar Haveli'),
(11, 'IN-GA', 'Goa'),
(12, 'IN-GJ', 'Gujarat'),
(13, 'IN-HP', 'Himachal Pradesh'),
(14, 'IN-HR', 'Haryana'),
(15, 'IN-JH', 'Jharkhand'),
(16, 'IN-JK', 'Jammu and Kashmir'),
(17, 'IN-KA', 'Karnataka'),
(18, 'IN-KL', 'Kerala'),
(19, 'IN-LD', 'Lakshadweep'),
(20, 'IN-MH', 'Maharashtra'),
(21, 'IN-ML', 'Meghalaya'),
(22, 'IN-MN', 'Manipur'),
(23, 'IN-MP', 'Madhya Pradesh'),
(24, 'IN-MZ', 'Mizoram'),
(25, 'IN-NL', 'Nagaland'),
(26, 'IN-OR', 'Odisha'),
(27, 'IN-PB', 'Punjab'),
(28, 'IN-PY', 'Puducherry'),
(29, 'IN-RJ', 'Rajasthan'),
(30, 'IN-SK', 'Sikkim'),
(31, 'IN-TG', 'Telangana'),
(32, 'IN-TN', 'Tamil Nadu'),
(33, 'IN-TR', 'Tripura'),
(34, 'IN-UP', 'Uttar Pradesh'),
(35, 'IN-UT', 'Uttarakhand'),
(36, 'IN-WB', 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE `stats` (
  `id` bigint(20) NOT NULL,
  `logins` bigint(20) NOT NULL,
  `rps` bigint(20) NOT NULL,
  `uids` bigint(20) NOT NULL,
  `ltime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stats`
--

INSERT INTO `stats` (`id`, `logins`, `rps`, `uids`, `ltime`) VALUES
(1, 1, 1, 1, '2018-01-24 10:31:58'),
(2, 3, 1, 1, '2018-01-24 03:48:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `name` varchar(65) NOT NULL,
  `username` varchar(65) NOT NULL,
  `email` varchar(65) NOT NULL,
  `designation` varchar(65) NOT NULL,
  `role` varchar(65) NOT NULL,
  `password` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `designation`, `role`, `password`) VALUES
(1, '', 'admin', '', '', 'Admin', 'e6e061838856bf47e1de730719fb2609');

-- --------------------------------------------------------

--
-- Table structure for table `userstats`
--

CREATE TABLE `userstats` (
  `id` bigint(20) NOT NULL,
  `session_id` varchar(250) NOT NULL,
  `log_date` varchar(50) NOT NULL,
  `user` varchar(80) NOT NULL,
  `sp` varchar(80) NOT NULL,
  `ip_address` varchar(250) NOT NULL,
  `idp` varchar(65) NOT NULL,
  `line_number` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userstats`
--

INSERT INTO `userstats` (`id`, `session_id`, `log_date`, `user`, `sp`, `ip_address`, `idp`, `line_number`) VALUES
(3, '_-508370690895049659', '17-06-2020 12:40:32', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(4, 'a1511gf7cd2866ei2deg2870jci619b', '10-07-2019 15:10:17', 'raja', 'https://fsso.springer.com', '14.139.114.162', '', ''),
(5, '_7cad113c5892d3d3b31f328c88abc51dcb5e2bbc22', '10-07-2019 16:33:40', 'raja', 'https://terena.org/sp', '172.16.21.239', '', ''),
(6, '_bdace438691cf3e6e803bdb413de8221', '30-11-2019 12:28:05', 'vaishalip', 'https://shibboleth.cambridge.org/shibboleth-sp', '117.196.38.6', '', ''),
(7, 'a28b80eefhdd278139j93ca4b997ic7', '30-11-2019 12:29:10', 'vaishalip', 'https://fsso.springer.com', '117.196.38.6', '', ''),
(8, '_53f2c663d0615aca27a4e31462d4995b', '04-12-2019 15:45:02', 'rajnish.ims@gmail.com', 'https://shibbolethsp.jstor.org/shibboleth', '172.16.0.125', '', ''),
(9, 'a7950e7236cjj5ch5be7h1564g8jc', '04-12-2019 15:45:28', 'rajnish.ims@gmail.com', 'https://fsso.springer.com', '172.16.0.125', '', ''),
(10, '_-691116412381484342', '09-12-2019 13:02:36', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '14.139.182.249', '', ''),
(11, '_3c373a6e00f4acee9dcf0a0c5d53efbe', '09-12-2019 23:16:06', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.193.96', '', ''),
(12, '_1a46f7e2ca68f9d839008526f839861a', '13-12-2019 10:24:57', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.213.235.232', '', ''),
(13, '_1084099008387560251', '21-12-2019 16:45:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '210.212.34.19', '', ''),
(14, '_-4931213504971454389', '25-12-2019 21:13:18', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.41.177', '', ''),
(15, '_e75dc05f7c309d540132ae5cf6ade152', '15-01-2020 12:04:36', 'vaishalip', 'https://shibboleth.cambridge.org/shibboleth-sp', '172.16.0.125', '', ''),
(16, '_6898188841281272131', '19-01-2020 16:16:31', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.44.80', '', ''),
(17, '_-3078599753285539263', '19-01-2020 16:19:10', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.44.80', '', ''),
(18, '_b4f840716842158015dcc993a2d61893', '19-01-2020 16:21:08', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(19, '_83261ff9a15413c745f6be0a4b6e0f77', '19-01-2020 16:21:57', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(20, '_21dc77b935f908a5330c0e8cf37f96dd', '19-01-2020 16:22:50', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(21, '_-1811222217829818690', '19-01-2020 22:19:03', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(22, '_-1818212032829104510', '19-01-2020 22:36:26', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(23, '_6045238319202368054', '21-01-2020 22:02:29', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.29.220', '', ''),
(24, '_-281208848430815475', '21-01-2020 22:59:43', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.29.220', '', ''),
(25, '_2681532419951700111', '23-01-2020 07:35:41', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.222.48.107', '', ''),
(26, '_-4650293910854844461', '23-01-2020 12:41:38', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.209.178.241', '', ''),
(27, '_-8247906570515767693', '23-01-2020 12:42:09', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.209.178.241', '', ''),
(28, '_8b8545c206ae153d2ab6d7bd6ae5347e', '23-01-2020 14:22:25', 'dinesh', 'https://sdauth.sciencedirect.com/', '172.16.21.58', '', ''),
(29, '_f4f872077ce5366946614de2a515b64431503eb7ff', '25-01-2020 13:59:06', 'raja', 'https://sp.emerald.com/sp', '14.192.29.154', '', ''),
(30, '_310016019c75e3e85605fdafdec7679b', '25-01-2020 15:33:33', 'raja', 'https://sdauth.sciencedirect.com/', '14.139.186.110', '', ''),
(31, '_9e59420aa364ce37d4b43548f91857b2', '25-01-2020 16:45:30', 'raja', 'https://sdauth.sciencedirect.com/', '14.139.186.110', '', ''),
(32, '_15801215202', '27-01-2020 16:09:37', 'vaishalip', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.125', '', ''),
(33, '_15801216063', '27-01-2020 16:10:45', 'raja', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.21.19', '', ''),
(34, '_-6177240669686412950', '04-02-2020 17:20:26', 'dinesh', 'https://pubs.acs.org/shibboleth', '14.139.182.249', '', ''),
(35, '_b33552e2c0ab3e2a3819a043d5b9a4e1', '05-02-2020 16:48:15', 'dinesh', 'https://sdauth.sciencedirect.com/', '172.16.0.32', '', ''),
(36, '_-8728488132460201592', '07-02-2020 14:34:06', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '14.139.182.249', '', ''),
(37, '_0aa471561e6c8b94a0ba20f5089c6d105882675ad2', '07-02-2020 15:55:33', 'raja', 'https://terena.org/sp', '172.16.21.31', '', ''),
(38, '_8167818128116097972', '20-02-2020 17:27:21', 'dinesh', 'https://pubs.acs.org/shibboleth', '172.16.21.193', '', ''),
(39, '_15828910514', '28-02-2020 17:28:23', 'dinesh', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.32', '', ''),
(40, '_3272892558042977982', '03-03-2020 13:48:22', 'vaishalip', 'https://iam.atypon.com/shibboleth', '172.16.0.125', '', ''),
(41, 'a414e55887i21jg91b0i9a98bbe7d6j', '03-03-2020 17:35:22', 'vaishalip', 'https://fsso.springer.com', '172.16.21.206', '', ''),
(42, '_3048542050309403596', '07-03-2020 09:14:33', 'raja', 'https://sp.tshhosting.com/shibboleth', '106.208.106.110', '', ''),
(43, '_c1ef6f812703e5f8519d7eab37f0934c', '07-03-2020 10:55:52', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.208.106.110', '', ''),
(44, '_921595dbbe031a6c05ec92a0fed86e89', '07-03-2020 10:58:14', 'raja', 'https://shibboleth.cambridge.org/shibboleth-sp', '106.208.106.110', '', ''),
(45, '_850c05b5a9a5cc8073248ef218cbc293', '09-03-2020 10:40:20', 'raja', 'https://infonet.inflibnet.ac.in/shibboleth', '172.16.21.76', '', ''),
(46, '_-2932582302106134751', '09-03-2020 18:17:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.223.243.119', '', ''),
(47, '_8349746088623469233', '09-03-2020 18:29:08', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.41.26.168', '', ''),
(48, '_4564403439012724082', '12-03-2020 13:22:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.88.232', '', ''),
(49, 'a1f0268jad85ad7e2g6856b24bh2891', '13-03-2020 14:07:08', 'raja', 'https://fsso.springer.com', '172.16.21.151', '', ''),
(50, '_54993d26eac8299a2c619e0c70a90e67', '13-03-2020 14:14:34', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '172.16.21.151', '', ''),
(51, '_-6849267166476916659', '14-03-2020 17:26:40', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.158.95', '', ''),
(52, '_5013666316679587277', '14-03-2020 18:47:40', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.158.95', '', ''),
(53, '_15849483770', '23-03-2020 12:55:33', 'raja', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.21.51', '', ''),
(54, '_15849484933', '23-03-2020 12:57:13', 'pstohrm@gov.in', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.32', '', ''),
(55, '_623c871d28a93e5e614d5159f45f2b2c', '23-03-2020 17:32:51', 'raja', 'https://secure.urkund.com/shibboleth', '172.16.21.51', '', ''),
(56, '_24ca9c2b11b020cc283d1d2108e85e5a', '25-03-2020 16:07:00', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(57, '_f2ee699ca9a9546fdb1edd488460e6df', '25-03-2020 16:07:59', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(58, '_5f8ac78a094803f91783bc64fbd845cc', '25-03-2020 16:08:51', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(59, '_eadf8d75d687ba6341f98943d44ead01', '25-03-2020 22:31:08', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(60, '_a034760b2765a6cab87ae7ea420b772d', '26-03-2020 10:45:11', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(61, '_8aac67398cb684e2b55ddde3fe4aa148', '26-03-2020 10:50:42', 'inflibnet_test', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(62, '_356d0bd50659239ed534a1f3f94f051e', '26-03-2020 17:51:45', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(63, '_41fa8a05b5b9a198476bedc49b04b461', '26-03-2020 17:54:46', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(64, '_ee0eb75eaf1da6ddbb1c1f78115d1c07', '26-03-2020 17:55:18', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(65, '_-5894425387816839491', '26-03-2020 17:56:26', 'raja', 'https://sp.tshhosting.com/shibboleth', '106.209.128.237', '', ''),
(66, '_5095237160033806921', '26-03-2020 17:57:11', 'raja', 'https://www.tandfonline.com/shibboleth', '106.209.128.237', '', ''),
(67, 'a3c60f9429ag945j12dh535hcd6c218', '26-03-2020 17:57:40', 'raja', 'https://fsso.springer.com', '106.209.128.237', '', ''),
(68, '_ec878b008fc7659859b557514fe60cec', '26-03-2020 17:58:11', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(69, '_-7588743384182545883', '27-03-2020 07:15:34', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.41.26.48', '', ''),
(70, '_-125640354114886955', '31-03-2020 23:00:51', 'vaishalip', 'https://sp.tshhosting.com/shibboleth', '117.196.40.115', '', ''),
(71, '_-1065463235237386553', '02-04-2020 18:29:14', 'hitesh', 'https://pubs.acs.org/shibboleth', '27.61.189.169', '', ''),
(72, '_9112056596676187398', '02-04-2020 18:33:05', 'hitesh', 'https://pubs.acs.org/shibboleth', '27.61.189.169', '', ''),
(73, '_4594072263364970828', '05-04-2020 09:53:39', 'raja', 'https://sp.tshhosting.com/shibboleth', '43.241.193.191', '', ''),
(74, '_-7684789290806129123', '10-04-2020 18:22:50', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(75, '_5691977688816129822', '10-04-2020 18:23:27', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(76, '_-5155161570089263014', '11-04-2020 09:15:50', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(77, '_89c620c227002fcc9a99ad76847204fd', '11-04-2020 21:11:44', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '14.139.128.10', '', ''),
(78, '_-7905645291772475940', '14-04-2020 18:53:09', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(79, '_-2025898409453375385', '14-04-2020 18:54:31', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(80, '_-4327219402781433249', '14-04-2020 18:59:06', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(81, '_6410468845986081683', '15-04-2020 16:29:22', 'slakhara', 'https://sp.tshhosting.com/shibboleth', '157.32.233.237', '', ''),
(82, '_-9219808748239124541', '15-04-2020 19:57:27', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.31.208', '', ''),
(83, '_1440284244314611229', '16-04-2020 22:49:25', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.29.208', '', ''),
(84, '_8047834480173496377', '16-04-2020 22:51:11', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.174.33.167', '', ''),
(85, '_8206006992713769402', '16-04-2020 22:51:25', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.174.33.167', '', ''),
(86, '_d399a86d376c6889fc7cfbd72a6a210d', '17-04-2020 12:38:42', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '103.210.51.62', '', ''),
(87, 'a3ehij9gii79eiha2e067gc7h393b26', '17-04-2020 12:39:44', 'raja', 'https://fsso.springer.com', '103.210.51.62', '', ''),
(88, '_2843691699386612689', '17-04-2020 14:44:57', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.160.236', '', ''),
(89, '_beb2eb6a241b56641969600bc3a27285', '18-04-2020 00:08:25', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.1.106', '', ''),
(90, '_57a622f4a69d6d9da1a3145d62b626a8', '18-04-2020 00:11:16', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.1.106', '', ''),
(91, '_-5012695645089849683', '18-04-2020 00:23:38', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.1.106', '', ''),
(92, '_-6432148679762654815', '18-04-2020 11:58:03', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.43.160', '', ''),
(93, '_8140630616320671810', '18-04-2020 12:28:46', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.24.88', '', ''),
(94, '_6052846032575378419', '18-04-2020 12:54:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.45.46', '', ''),
(95, '_c19f9b2603ae8b4f088295cd2ff8e905', '18-04-2020 13:09:54', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.45.46', '', ''),
(96, '_2777141779126598878', '18-04-2020 14:30:36', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.160.72', '', ''),
(97, '_-7766544642906234163', '19-04-2020 12:37:39', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.138.138', '', ''),
(98, '_-321737714132682774', '20-04-2020 13:36:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.89.56', '', ''),
(99, '_70737423827413041057fe27e7e215ff', '20-04-2020 18:53:13', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.122.227', '', ''),
(100, '_-5935188913653688179', '20-04-2020 19:03:05', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.122.227', '', ''),
(101, '_53a3815b23402f8d3469c924a8929178', '20-04-2020 19:53:21', 'kannan', 'https://muse.jhu.edu/shibboleth', '157.50.122.227', '', ''),
(102, '_6631949640170005904', '20-04-2020 19:53:22', 'kannan', 'https://www.tandfonline.com/shibboleth', '157.50.122.227', '', ''),
(103, '_-9166585717287801843', '20-04-2020 19:53:53', 'kannan', 'https://www.tandfonline.com/shibboleth', '157.50.122.227', '', ''),
(104, '_-6009469426330644914', '20-04-2020 21:34:05', 'kannan', 'https://iam.atypon.com/shibboleth', '157.50.122.227', '', ''),
(105, '_9ff557322e248d409bfaddc6fedf6389', '20-04-2020 21:39:10', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.122.227', '', ''),
(106, '_7407f26b37e5e722703597d901dce433', '21-04-2020 10:21:18', 'raja', 'https://evento.renater.fr/', '43.241.194.224', '', ''),
(107, '_d9ecf3b0ee39b1d0bf0c0f5dede94dee', '21-04-2020 10:21:47', 'raja', 'https://evento.renater.fr/', '43.241.194.224', '', ''),
(108, '_111daf9a05e9a4a1ed4e1aad7a6e15cc', '21-04-2020 11:24:13', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.206.1.25', '', ''),
(109, '_-8853983496294840003', '21-04-2020 11:27:35', 'raja', 'https://iam.atypon.com/shibboleth', '106.206.1.25', '', ''),
(110, 'a351gg0659583ia057321abehed338h', '23-04-2020 12:15:02', 'raja', 'https://fsso.springer.com', '172.16.0.32', '', ''),
(111, '_6731124716630256349', '23-04-2020 17:48:26', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.197.80', '', ''),
(112, '_-3801051842761213055', '23-04-2020 20:39:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.203.79.140', '', ''),
(113, '_-7549374581354833251', '23-04-2020 20:48:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.210', '', ''),
(114, '_-3651927221160507481', '23-04-2020 20:50:07', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.210', '', ''),
(115, 'a4icb83ia3h8e9a9226hh16g38999e', '23-04-2020 20:59:54', 'kannan', 'https://fsso.springer.com', '157.50.239.215', '', ''),
(116, '_385743763839117047', '24-04-2020 19:06:28', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.130.62', '', ''),
(117, '_2257299484029659190', '25-04-2020 00:46:47', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(118, '_5b5121d2922e1ca03bf5109b1bfedd54', '25-04-2020 15:36:42', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '136.233.33.82', '', ''),
(119, 'a1hb50f5j82ed66a21dgcbe2c870b5h', '25-04-2020 15:38:24', 'raja', 'https://fsso.springer.com', '136.233.33.82', '', ''),
(120, '_-5067559062283664522', '25-04-2020 19:01:11', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.137.41', '', ''),
(121, '_5478516627115837241', '25-04-2020 20:41:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.223.67', '', ''),
(122, '_1153924279526288677', '26-04-2020 15:11:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.197.161.54', '', ''),
(123, '_-1342403830472005679', '26-04-2020 15:12:30', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.197.161.54', '', ''),
(124, '_4513493428276143497', '26-04-2020 17:52:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.159.113', '', ''),
(125, '_1340716691355208093', '27-04-2020 15:29:04', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.203.51.209', '', ''),
(126, '_-338111969701326324', '28-04-2020 09:21:03', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.165.119', '', ''),
(127, '_1771708215573540836', '28-04-2020 17:29:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.174.47', '', ''),
(128, '_-3283893904663985340', '29-04-2020 10:51:44', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.165.117', '', ''),
(129, '_-8354717059034254582', '29-04-2020 11:12:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.162.208', '', ''),
(130, '_-6921878115217459429', '29-04-2020 16:45:36', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.192', '', ''),
(131, '_-2903428664249389815', '29-04-2020 17:32:01', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.161.148', '', ''),
(132, '_-4805300095990206519', '30-04-2020 16:19:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.146.33', '', ''),
(133, 'a1f82ea9ea5j0ijbbgb4bjd5ghddje', '30-04-2020 16:23:13', 'kannan', 'https://fsso.springer.com', '42.111.136.211', '', ''),
(134, '_-2614444209526768904', '30-04-2020 16:27:07', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.136.211', '', ''),
(135, '_2498844586143537330', '30-04-2020 16:33:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.241.230', '', ''),
(136, '_-983188241681303332', '01-05-2020 15:16:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.46.74.72', '', ''),
(137, '_7053756191510894437', '02-05-2020 09:40:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.46.45.80', '', ''),
(138, '_-8013516033613784803', '02-05-2020 20:19:34', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.180', '', ''),
(139, '_2327070250621596616', '03-05-2020 09:39:19', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.180.89', '', ''),
(140, '_fbd1725579db4925b6ded937b5b866d4', '04-05-2020 11:45:02', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '43.241.194.70', '', ''),
(141, 'a397hi67gc29gdgi296gci52d1jd32g', '04-05-2020 11:45:34', 'raja', 'https://fsso.springer.com', '43.241.194.70', '', ''),
(142, '_1588584004247', '04-05-2020 14:53:17', 'hitesh', 'https://web.inflibnet.ac.in:2048/Shibboleth', '27.61.143.252', '', ''),
(143, '_-7615685482353884432', '05-05-2020 11:42:55', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.220.81', '', ''),
(144, '_2994804807199565841', '05-05-2020 11:45:41', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.220.81', '', ''),
(145, '_-6947595868510875198', '05-05-2020 15:34:23', 'roma', 'https://ieeexplore.ieee.org/shibboleth-sp', '42.106.44.218', '', ''),
(146, '_-6592670487898789142', '05-05-2020 16:44:18', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.24', '', ''),
(147, '_9030635383293935081', '06-05-2020 19:53:03', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.167.40', '', ''),
(148, '_-6340420369647269287', '08-05-2020 13:31:10', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.96', '', ''),
(149, '_1589096536254', '10-05-2020 13:10:22', 'pstohrm@gov.in', 'https://web.inflibnet.ac.in:2048/Shibboleth', '103.49.226.140', '', ''),
(150, '_e871e898aec3ad65f384092ad9f6cf51', '10-05-2020 13:11:06', 'pstohrm@gov.in', 'https://shibboleth.cambridge.org/shibboleth-sp', '103.49.226.140', '', ''),
(151, '_-2823677313162555207', '10-05-2020 13:11:27', 'pstohrm@gov.in', 'https://sp.tshhosting.com/shibboleth', '103.49.226.140', '', ''),
(152, '_5b33c352373eb769c856ccbf0650ae79', '10-05-2020 13:11:41', 'pstohrm@gov.in', 'https://shibboleth.cambridge.org/shibboleth-sp', '103.49.226.140', '', ''),
(153, '_6328733253946382290', '12-05-2020 05:59:10', 'raja', 'https://pubs.acs.org/shibboleth', '106.213.232.175', '', ''),
(154, '_6794220445803757665', '13-05-2020 23:15:41', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(155, '_3452750570131613034', '13-05-2020 23:16:19', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(156, '_1657159877837470200', '14-05-2020 09:30:48', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(157, '_143950033638151927', '15-05-2020 02:40:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.178.79.75', '', ''),
(158, '_-4595896794809226003', '16-05-2020 14:28:05', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '49.34.118.198', '', ''),
(159, '_2f88443ebfbf3aac08711ee19235af21', '18-05-2020 17:11:02', 'siva', 'https://shibbolethsp.jstor.org/shibboleth', '106.222.33.65', '', ''),
(160, '_4586874500702221092', '18-05-2020 17:27:56', 'siva', 'https://www.tandfonline.com/shibboleth', '106.222.33.65', '', ''),
(161, '_2053027356590015237', '18-05-2020 17:28:38', 'siva', 'https://www.tandfonline.com/shibboleth', '106.222.33.65', '', ''),
(162, '_-771736414359368459', '19-05-2020 10:31:16', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.72', '', ''),
(163, '_3163700571167524088', '24-05-2020 12:25:42', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.215.168', '', ''),
(164, '_6461990602126770855', '24-05-2020 12:26:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.215.168', '', ''),
(165, '_8116113545601911087', '25-05-2020 05:14:29', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.187.253', '', ''),
(166, '_-3095860904028982226', '25-05-2020 14:33:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.164.252.131', '', ''),
(167, '_0757e897d8d9ebd5b87584325c9d4985', '28-05-2020 07:44:49', 'raja', 'https://infonet.inflibnet.ac.in/shibboleth', '43.241.193.10', '', ''),
(168, '_3654845525212001611', '28-05-2020 07:46:18', 'raja', 'https://sp.tshhosting.com/shibboleth', '43.241.193.10', '', ''),
(169, '_-7316757533659170896', '28-05-2020 12:45:39', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.166', '', ''),
(170, '_-5626859718385963639', '28-05-2020 12:46:20', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.166', '', ''),
(171, '_-310125273844595342', '29-05-2020 12:05:48', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '49.34.94.125', '', ''),
(172, '_-2003877682142744197', '30-05-2020 10:20:57', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.16.205', '', ''),
(173, '_7104956898537012904', '31-05-2020 20:16:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.51.208', '', ''),
(174, '_4266715877656935258', '01-06-2020 17:21:33', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(175, '_-3978307022854945102', '01-06-2020 18:02:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.255.59', '', ''),
(176, '_08eb4c82c6488a9b064bf8b624c0b538', '01-06-2020 20:27:27', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.51.255.59', '', ''),
(177, '_8b5dbc46e4db41a4f572bb0a686e40b1', '01-06-2020 20:27:54', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.51.86.180', '', ''),
(178, '_-3022774430495460218', '03-06-2020 10:13:16', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(179, '_3436410584594581557', '04-06-2020 11:10:30', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(180, '_1580502236159479932', '07-06-2020 11:20:59', 'raja', 'https://iam.atypon.com/shibboleth', '43.241.194.168', '', ''),
(181, '_-2197429264807443286', '08-06-2020 13:27:46', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(182, '_-7964839695333479060', '09-06-2020 14:58:42', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(183, '_7119935393868534797', '09-06-2020 14:59:15', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(184, '_d644e4f008e9223f364190de0d580d625bfd9ea335', '09-06-2020 16:06:52', 'raja', 'https://terena.org/sp', '172.16.21.132', '', ''),
(185, '_5806383969258744600', '10-06-2020 10:48:07', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(186, '_-7476247209024122885', '12-06-2020 10:19:11', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(187, 'a3jiegi33102gjfdg1a8ja6ii87915', '15-06-2020 10:23:51', 'raja', 'https://fsso.springer.com', '27.4.61.247', '', ''),
(188, '_027349959eeb05ea73cdbbab08d5f15f', '15-06-2020 10:26:46', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '27.4.61.247', '', ''),
(189, '_-1680610440771674203', '15-06-2020 10:47:01', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(190, '_9026771198995593938', '16-06-2020 10:53:02', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(191, 'a3jiegi33102gjfdg1a8ja6ii87915', '2020-06-15 10:23:51', 'raja', 'https://fsso.springer.com', '27.4.61.247', '', ''),
(192, '_027349959eeb05ea73cdbbab08d5f15f', '2020-06-15 10:26:46', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '27.4.61.247', '', ''),
(193, '_-1680610440771674203', '2020-06-15 10:47:01', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(194, 'a1511gf7cd2866ei2deg2870jci619b', '2019-07-10 15:10:17', 'raja', 'https://fsso.springer.com', '14.139.114.162', '', ''),
(195, '_7cad113c5892d3d3b31f328c88abc51dcb5e2bbc22', '2019-07-10 16:33:40', 'raja', 'https://terena.org/sp', '172.16.21.239', '', ''),
(196, '_bdace438691cf3e6e803bdb413de8221', '2019-11-30 12:28:05', 'vaishalip', 'https://shibboleth.cambridge.org/shibboleth-sp', '117.196.38.6', '', ''),
(197, 'a28b80eefhdd278139j93ca4b997ic7', '2019-11-30 12:29:10', 'vaishalip', 'https://fsso.springer.com', '117.196.38.6', '', ''),
(198, '_53f2c663d0615aca27a4e31462d4995b', '2019-12-04 15:45:02', 'rajnish.ims@gmail.com', 'https://shibbolethsp.jstor.org/shibboleth', '172.16.0.125', '', ''),
(199, 'a7950e7236cjj5ch5be7h1564g8jc', '2019-12-04 15:45:28', 'rajnish.ims@gmail.com', 'https://fsso.springer.com', '172.16.0.125', '', ''),
(200, '_-691116412381484342', '2019-12-09 13:02:36', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '14.139.182.249', '', ''),
(201, '_3c373a6e00f4acee9dcf0a0c5d53efbe', '2019-12-09 23:16:06', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.193.96', '', ''),
(202, '_1a46f7e2ca68f9d839008526f839861a', '2019-12-13 10:24:57', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.213.235.232', '', ''),
(203, '_1084099008387560251', '2019-12-21 16:45:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '210.212.34.19', '', ''),
(204, '_-4931213504971454389', '2019-12-25 21:13:18', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.41.177', '', ''),
(205, '_e75dc05f7c309d540132ae5cf6ade152', '2020-01-15 12:04:36', 'vaishalip', 'https://shibboleth.cambridge.org/shibboleth-sp', '172.16.0.125', '', ''),
(206, '_6898188841281272131', '2020-01-19 16:16:31', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.44.80', '', ''),
(207, '_-3078599753285539263', '2020-01-19 16:19:10', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.44.80', '', ''),
(208, '_b4f840716842158015dcc993a2d61893', '2020-01-19 16:21:08', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(209, '_83261ff9a15413c745f6be0a4b6e0f77', '2020-01-19 16:21:57', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(210, '_21dc77b935f908a5330c0e8cf37f96dd', '2020-01-19 16:22:50', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.44.80', '', ''),
(211, '_-1811222217829818690', '2020-01-19 22:19:03', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(212, '_-1818212032829104510', '2020-01-19 22:36:26', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(213, '_6045238319202368054', '2020-01-21 22:02:29', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.29.220', '', ''),
(214, '_-281208848430815475', '2020-01-21 22:59:43', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.29.220', '', ''),
(215, '_2681532419951700111', '2020-01-23 07:35:41', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.222.48.107', '', ''),
(216, '_-4650293910854844461', '2020-01-23 12:41:38', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.209.178.241', '', ''),
(217, '_-8247906570515767693', '2020-01-23 12:42:09', 'siva', 'https://sp.tshhosting.com/shibboleth', '106.209.178.241', '', ''),
(218, '_8b8545c206ae153d2ab6d7bd6ae5347e', '2020-01-23 14:22:25', 'dinesh', 'https://sdauth.sciencedirect.com/', '172.16.21.58', '', ''),
(219, '_f4f872077ce5366946614de2a515b64431503eb7ff', '2020-01-25 13:59:06', 'raja', 'https://sp.emerald.com/sp', '14.192.29.154', '', ''),
(220, '_310016019c75e3e85605fdafdec7679b', '2020-01-25 15:33:33', 'raja', 'https://sdauth.sciencedirect.com/', '14.139.186.110', '', ''),
(221, '_9e59420aa364ce37d4b43548f91857b2', '2020-01-25 16:45:30', 'raja', 'https://sdauth.sciencedirect.com/', '14.139.186.110', '', ''),
(222, '_15801215202', '2020-01-27 16:09:37', 'vaishalip', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.125', '', ''),
(223, '_15801216063', '2020-01-27 16:10:45', 'raja', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.21.19', '', ''),
(224, '_-6177240669686412950', '2020-02-04 17:20:26', 'dinesh', 'https://pubs.acs.org/shibboleth', '14.139.182.249', '', ''),
(225, '_b33552e2c0ab3e2a3819a043d5b9a4e1', '2020-02-05 16:48:15', 'dinesh', 'https://sdauth.sciencedirect.com/', '172.16.0.32', '', ''),
(226, '_-8728488132460201592', '2020-02-07 14:34:06', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '14.139.182.249', '', ''),
(227, '_0aa471561e6c8b94a0ba20f5089c6d105882675ad2', '2020-02-07 15:55:33', 'raja', 'https://terena.org/sp', '172.16.21.31', '', ''),
(228, '_8167818128116097972', '2020-02-20 17:27:21', 'dinesh', 'https://pubs.acs.org/shibboleth', '172.16.21.193', '', ''),
(229, '_15828910514', '2020-02-28 17:28:23', 'dinesh', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.32', '', ''),
(230, '_3272892558042977982', '2020-03-03 13:48:22', 'vaishalip', 'https://iam.atypon.com/shibboleth', '172.16.0.125', '', ''),
(231, 'a414e55887i21jg91b0i9a98bbe7d6j', '2020-03-03 17:35:22', 'vaishalip', 'https://fsso.springer.com', '172.16.21.206', '', ''),
(232, '_3048542050309403596', '2020-03-07 09:14:33', 'raja', 'https://sp.tshhosting.com/shibboleth', '106.208.106.110', '', ''),
(233, '_c1ef6f812703e5f8519d7eab37f0934c', '2020-03-07 10:55:52', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.208.106.110', '', ''),
(234, '_921595dbbe031a6c05ec92a0fed86e89', '2020-03-07 10:58:14', 'raja', 'https://shibboleth.cambridge.org/shibboleth-sp', '106.208.106.110', '', ''),
(235, '_850c05b5a9a5cc8073248ef218cbc293', '2020-03-09 10:40:20', 'raja', 'https://infonet.inflibnet.ac.in/shibboleth', '172.16.21.76', '', ''),
(236, '_-2932582302106134751', '2020-03-09 18:17:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.223.243.119', '', ''),
(237, '_8349746088623469233', '2020-03-09 18:29:08', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.41.26.168', '', ''),
(238, '_4564403439012724082', '2020-03-12 13:22:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.88.232', '', ''),
(239, 'a1f0268jad85ad7e2g6856b24bh2891', '2020-03-13 14:07:08', 'raja', 'https://fsso.springer.com', '172.16.21.151', '', ''),
(240, '_54993d26eac8299a2c619e0c70a90e67', '2020-03-13 14:14:34', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '172.16.21.151', '', ''),
(241, '_-6849267166476916659', '2020-03-14 17:26:40', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.158.95', '', ''),
(242, '_5013666316679587277', '2020-03-14 18:47:40', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.39.158.95', '', ''),
(243, '_15849483770', '2020-03-23 12:55:33', 'raja', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.21.51', '', ''),
(244, '_15849484933', '2020-03-23 12:57:13', 'pstohrm@gov.in', 'https://web.inflibnet.ac.in:2048/Shibboleth', '172.16.0.32', '', ''),
(245, '_623c871d28a93e5e614d5159f45f2b2c', '2020-03-23 17:32:51', 'raja', 'https://secure.urkund.com/shibboleth', '172.16.21.51', '', ''),
(246, '_24ca9c2b11b020cc283d1d2108e85e5a', '2020-03-25 16:07:00', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(247, '_f2ee699ca9a9546fdb1edd488460e6df', '2020-03-25 16:07:59', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(248, '_5f8ac78a094803f91783bc64fbd845cc', '2020-03-25 16:08:51', 'dinesh', 'https://sdauth.sciencedirect.com/', '49.34.129.39', '', ''),
(249, '_eadf8d75d687ba6341f98943d44ead01', '2020-03-25 22:31:08', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(250, '_a034760b2765a6cab87ae7ea420b772d', '2020-03-26 10:45:11', 'raja', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(251, '_8aac67398cb684e2b55ddde3fe4aa148', '2020-03-26 10:50:42', 'inflibnet_test', 'https://sdauth.sciencedirect.com/', '43.241.194.157', '', ''),
(252, '_356d0bd50659239ed534a1f3f94f051e', '2020-03-26 17:51:45', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(253, '_41fa8a05b5b9a198476bedc49b04b461', '2020-03-26 17:54:46', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(254, '_ee0eb75eaf1da6ddbb1c1f78115d1c07', '2020-03-26 17:55:18', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(255, '_-5894425387816839491', '2020-03-26 17:56:26', 'raja', 'https://sp.tshhosting.com/shibboleth', '106.209.128.237', '', ''),
(256, '_5095237160033806921', '2020-03-26 17:57:11', 'raja', 'https://www.tandfonline.com/shibboleth', '106.209.128.237', '', ''),
(257, 'a3c60f9429ag945j12dh535hcd6c218', '2020-03-26 17:57:40', 'raja', 'https://fsso.springer.com', '106.209.128.237', '', ''),
(258, '_ec878b008fc7659859b557514fe60cec', '2020-03-26 17:58:11', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.209.128.237', '', ''),
(259, '_-7588743384182545883', '2020-03-27 07:15:34', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.41.26.48', '', ''),
(260, '_-125640354114886955', '2020-03-31 23:00:51', 'vaishalip', 'https://sp.tshhosting.com/shibboleth', '117.196.40.115', '', ''),
(261, '_-1065463235237386553', '2020-04-02 18:29:14', 'hitesh', 'https://pubs.acs.org/shibboleth', '27.61.189.169', '', ''),
(262, '_9112056596676187398', '2020-04-02 18:33:05', 'hitesh', 'https://pubs.acs.org/shibboleth', '27.61.189.169', '', ''),
(263, '_4594072263364970828', '2020-04-05 09:53:39', 'raja', 'https://sp.tshhosting.com/shibboleth', '43.241.193.191', '', ''),
(264, '_-7684789290806129123', '2020-04-10 18:22:50', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(265, '_5691977688816129822', '2020-04-10 18:23:27', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(266, '_-5155161570089263014', '2020-04-11 09:15:50', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.223.9.216', '', ''),
(267, '_89c620c227002fcc9a99ad76847204fd', '2020-04-11 21:11:44', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '14.139.128.10', '', ''),
(268, '_-7905645291772475940', '2020-04-14 18:53:09', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(269, '_-2025898409453375385', '2020-04-14 18:54:31', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(270, '_-4327219402781433249', '2020-04-14 18:59:06', 'kannan', 'https://sp.tshhosting.com/shibboleth', '202.14.120.120', '', ''),
(271, '_6410468845986081683', '2020-04-15 16:29:22', 'slakhara', 'https://sp.tshhosting.com/shibboleth', '157.32.233.237', '', ''),
(272, '_-9219808748239124541', '2020-04-15 19:57:27', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.31.208', '', ''),
(273, '_1440284244314611229', '2020-04-16 22:49:25', 'kannan', 'https://sp.tshhosting.com/shibboleth', '117.241.29.208', '', ''),
(274, '_8047834480173496377', '2020-04-16 22:51:11', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.174.33.167', '', ''),
(275, '_8206006992713769402', '2020-04-16 22:51:25', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.174.33.167', '', ''),
(276, '_d399a86d376c6889fc7cfbd72a6a210d', '2020-04-17 12:38:42', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '103.210.51.62', '', ''),
(277, 'a3ehij9gii79eiha2e067gc7h393b26', '2020-04-17 12:39:44', 'raja', 'https://fsso.springer.com', '103.210.51.62', '', ''),
(278, '_2843691699386612689', '2020-04-17 14:44:57', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.160.236', '', ''),
(279, '_beb2eb6a241b56641969600bc3a27285', '2020-04-18 00:08:25', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.1.106', '', ''),
(280, '_57a622f4a69d6d9da1a3145d62b626a8', '2020-04-18 00:11:16', 'roma', 'https://sdauth.sciencedirect.com/', '42.106.1.106', '', ''),
(281, '_-5012695645089849683', '2020-04-18 00:23:38', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.1.106', '', ''),
(282, '_-6432148679762654815', '2020-04-18 11:58:03', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.43.160', '', ''),
(283, '_8140630616320671810', '2020-04-18 12:28:46', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.24.88', '', ''),
(284, '_6052846032575378419', '2020-04-18 12:54:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.45.46', '', ''),
(285, '_c19f9b2603ae8b4f088295cd2ff8e905', '2020-04-18 13:09:54', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.45.46', '', ''),
(286, '_2777141779126598878', '2020-04-18 14:30:36', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.160.72', '', ''),
(287, '_-7766544642906234163', '2020-04-19 12:37:39', 'kannan', 'https://sp.tshhosting.com/shibboleth', '223.228.138.138', '', ''),
(288, '_-321737714132682774', '2020-04-20 13:36:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.89.56', '', ''),
(289, '_70737423827413041057fe27e7e215ff', '2020-04-20 18:53:13', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.122.227', '', ''),
(290, '_-5935188913653688179', '2020-04-20 19:03:05', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.122.227', '', ''),
(291, '_53a3815b23402f8d3469c924a8929178', '2020-04-20 19:53:21', 'kannan', 'https://muse.jhu.edu/shibboleth', '157.50.122.227', '', ''),
(292, '_6631949640170005904', '2020-04-20 19:53:22', 'kannan', 'https://www.tandfonline.com/shibboleth', '157.50.122.227', '', ''),
(293, '_-9166585717287801843', '2020-04-20 19:53:53', 'kannan', 'https://www.tandfonline.com/shibboleth', '157.50.122.227', '', ''),
(294, '_-6009469426330644914', '2020-04-20 21:34:05', 'kannan', 'https://iam.atypon.com/shibboleth', '157.50.122.227', '', ''),
(295, '_9ff557322e248d409bfaddc6fedf6389', '2020-04-20 21:39:10', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.50.122.227', '', ''),
(296, '_7407f26b37e5e722703597d901dce433', '2020-04-21 10:21:18', 'raja', 'https://evento.renater.fr/', '43.241.194.224', '', ''),
(297, '_d9ecf3b0ee39b1d0bf0c0f5dede94dee', '2020-04-21 10:21:47', 'raja', 'https://evento.renater.fr/', '43.241.194.224', '', ''),
(298, '_111daf9a05e9a4a1ed4e1aad7a6e15cc', '2020-04-21 11:24:13', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '106.206.1.25', '', ''),
(299, '_-8853983496294840003', '2020-04-21 11:27:35', 'raja', 'https://iam.atypon.com/shibboleth', '106.206.1.25', '', ''),
(300, 'a351gg0659583ia057321abehed338h', '2020-04-23 12:15:02', 'raja', 'https://fsso.springer.com', '172.16.0.32', '', ''),
(301, '_6731124716630256349', '2020-04-23 17:48:26', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.197.80', '', ''),
(302, '_-3801051842761213055', '2020-04-23 20:39:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.203.79.140', '', ''),
(303, '_-7549374581354833251', '2020-04-23 20:48:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.210', '', ''),
(304, '_-3651927221160507481', '2020-04-23 20:50:07', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.210', '', ''),
(305, 'a4icb83ia3h8e9a9226hh16g38999e', '2020-04-23 20:59:54', 'kannan', 'https://fsso.springer.com', '157.50.239.215', '', ''),
(306, '_385743763839117047', '2020-04-24 19:06:28', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.130.62', '', ''),
(307, '_2257299484029659190', '2020-04-25 00:46:47', 'roma', 'https://sp.tshhosting.com/shibboleth', '42.106.46.201', '', ''),
(308, '_5b5121d2922e1ca03bf5109b1bfedd54', '2020-04-25 15:36:42', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '136.233.33.82', '', ''),
(309, 'a1hb50f5j82ed66a21dgcbe2c870b5h', '2020-04-25 15:38:24', 'raja', 'https://fsso.springer.com', '136.233.33.82', '', ''),
(310, '_-5067559062283664522', '2020-04-25 19:01:11', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.137.41', '', ''),
(311, '_5478516627115837241', '2020-04-25 20:41:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.223.67', '', ''),
(312, '_1153924279526288677', '2020-04-26 15:11:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.197.161.54', '', ''),
(313, '_-1342403830472005679', '2020-04-26 15:12:30', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.197.161.54', '', ''),
(314, '_4513493428276143497', '2020-04-26 17:52:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.159.113', '', ''),
(315, '_1340716691355208093', '2020-04-27 15:29:04', 'kannan', 'https://sp.tshhosting.com/shibboleth', '106.203.51.209', '', ''),
(316, '_-338111969701326324', '2020-04-28 09:21:03', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.165.119', '', ''),
(317, '_1771708215573540836', '2020-04-28 17:29:59', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.174.47', '', ''),
(318, '_-3283893904663985340', '2020-04-29 10:51:44', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.165.117', '', ''),
(319, '_-8354717059034254582', '2020-04-29 11:12:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.162.208', '', ''),
(320, '_-6921878115217459429', '2020-04-29 16:45:36', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.192', '', ''),
(321, '_-2903428664249389815', '2020-04-29 17:32:01', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.161.148', '', ''),
(322, '_-4805300095990206519', '2020-04-30 16:19:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.146.33', '', ''),
(323, 'a1f82ea9ea5j0ijbbgb4bjd5ghddje', '2020-04-30 16:23:13', 'kannan', 'https://fsso.springer.com', '42.111.136.211', '', ''),
(324, '_-2614444209526768904', '2020-04-30 16:27:07', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.136.211', '', ''),
(325, '_2498844586143537330', '2020-04-30 16:33:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.241.230', '', ''),
(326, '_-983188241681303332', '2020-05-01 15:16:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.46.74.72', '', ''),
(327, '_7053756191510894437', '2020-05-02 09:40:35', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.46.45.80', '', ''),
(328, '_-8013516033613784803', '2020-05-02 20:19:34', 'kannan', 'https://sp.tshhosting.com/shibboleth', '42.111.144.180', '', ''),
(329, '_2327070250621596616', '2020-05-03 09:39:19', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.180.89', '', ''),
(330, '_fbd1725579db4925b6ded937b5b866d4', '2020-05-04 11:45:02', 'raja', 'https://shibbolethsp.jstor.org/shibboleth', '43.241.194.70', '', ''),
(331, 'a397hi67gc29gdgi296gci52d1jd32g', '2020-05-04 11:45:34', 'raja', 'https://fsso.springer.com', '43.241.194.70', '', ''),
(332, '_1588584004247', '2020-05-04 14:53:17', 'hitesh', 'https://web.inflibnet.ac.in:2048/Shibboleth', '27.61.143.252', '', ''),
(333, '_-7615685482353884432', '2020-05-05 11:42:55', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.220.81', '', ''),
(334, '_2994804807199565841', '2020-05-05 11:45:41', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.220.81', '', ''),
(335, '_-6947595868510875198', '2020-05-05 15:34:23', 'roma', 'https://ieeexplore.ieee.org/shibboleth-sp', '42.106.44.218', '', ''),
(336, '_-6592670487898789142', '2020-05-05 16:44:18', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.24', '', ''),
(337, '_9030635383293935081', '2020-05-06 19:53:03', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.167.40', '', ''),
(338, '_-6340420369647269287', '2020-05-08 13:31:10', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.96', '', ''),
(339, '_1589096536254', '2020-05-10 13:10:22', 'pstohrm@gov.in', 'https://web.inflibnet.ac.in:2048/Shibboleth', '103.49.226.140', '', ''),
(340, '_e871e898aec3ad65f384092ad9f6cf51', '2020-05-10 13:11:06', 'pstohrm@gov.in', 'https://shibboleth.cambridge.org/shibboleth-sp', '103.49.226.140', '', ''),
(341, '_-2823677313162555207', '2020-05-10 13:11:27', 'pstohrm@gov.in', 'https://sp.tshhosting.com/shibboleth', '103.49.226.140', '', ''),
(342, '_5b33c352373eb769c856ccbf0650ae79', '2020-05-10 13:11:41', 'pstohrm@gov.in', 'https://shibboleth.cambridge.org/shibboleth-sp', '103.49.226.140', '', ''),
(343, '_6328733253946382290', '2020-05-12 05:59:10', 'raja', 'https://pubs.acs.org/shibboleth', '106.213.232.175', '', ''),
(344, '_6794220445803757665', '2020-05-13 23:15:41', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(345, '_3452750570131613034', '2020-05-13 23:16:19', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(346, '_1657159877837470200', '2020-05-14 09:30:48', 'pallab', 'https://sp.tshhosting.com/shibboleth', '106.213.174.91', '', ''),
(347, '_143950033638151927', '2020-05-15 02:40:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.178.79.75', '', ''),
(348, '_-4595896794809226003', '2020-05-16 14:28:05', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '49.34.118.198', '', ''),
(349, '_2f88443ebfbf3aac08711ee19235af21', '2020-05-18 17:11:02', 'siva', 'https://shibbolethsp.jstor.org/shibboleth', '106.222.33.65', '', ''),
(350, '_4586874500702221092', '2020-05-18 17:27:56', 'siva', 'https://www.tandfonline.com/shibboleth', '106.222.33.65', '', ''),
(351, '_2053027356590015237', '2020-05-18 17:28:38', 'siva', 'https://www.tandfonline.com/shibboleth', '106.222.33.65', '', ''),
(352, '_-771736414359368459', '2020-05-19 10:31:16', 'kannan', 'https://sp.tshhosting.com/shibboleth', '103.66.209.72', '', ''),
(353, '_3163700571167524088', '2020-05-24 12:25:42', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.215.168', '', ''),
(354, '_6461990602126770855', '2020-05-24 12:26:02', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.215.168', '', ''),
(355, '_8116113545601911087', '2020-05-25 05:14:29', 'kannan', 'https://sp.tshhosting.com/shibboleth', '182.65.187.253', '', ''),
(356, '_-3095860904028982226', '2020-05-25 14:33:38', 'kannan', 'https://sp.tshhosting.com/shibboleth', '122.164.252.131', '', ''),
(357, '_0757e897d8d9ebd5b87584325c9d4985', '2020-05-28 07:44:49', 'raja', 'https://infonet.inflibnet.ac.in/shibboleth', '43.241.193.10', '', ''),
(358, '_3654845525212001611', '2020-05-28 07:46:18', 'raja', 'https://sp.tshhosting.com/shibboleth', '43.241.193.10', '', ''),
(359, '_-7316757533659170896', '2020-05-28 12:45:39', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.166', '', ''),
(360, '_-5626859718385963639', '2020-05-28 12:46:20', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.166', '', ''),
(361, '_-310125273844595342', '2020-05-29 12:05:48', 'dinesh', 'https://sp.tshhosting.com/shibboleth', '49.34.94.125', '', ''),
(362, '_-2003877682142744197', '2020-05-30 10:20:57', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.16.205', '', ''),
(363, '_7104956898537012904', '2020-05-31 20:16:48', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.50.51.208', '', ''),
(364, '_4266715877656935258', '2020-06-01 17:21:33', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(365, '_-3978307022854945102', '2020-06-01 18:02:51', 'kannan', 'https://sp.tshhosting.com/shibboleth', '157.51.255.59', '', ''),
(366, '_08eb4c82c6488a9b064bf8b624c0b538', '2020-06-01 20:27:27', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.51.255.59', '', ''),
(367, '_8b5dbc46e4db41a4f572bb0a686e40b1', '2020-06-01 20:27:54', 'kannan', 'https://shibbolethsp.jstor.org/shibboleth', '157.51.86.180', '', ''),
(368, '_-3022774430495460218', '2020-06-03 10:13:16', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(369, '_3436410584594581557', '2020-06-04 11:10:30', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.185', '', ''),
(370, '_1580502236159479932', '2020-06-07 11:20:59', 'raja', 'https://iam.atypon.com/shibboleth', '43.241.194.168', '', ''),
(371, '_-2197429264807443286', '2020-06-08 13:27:46', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(372, '_-7964839695333479060', '2020-06-09 14:58:42', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(373, '_7119935393868534797', '2020-06-09 14:59:15', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(374, '_d644e4f008e9223f364190de0d580d625bfd9ea335', '2020-06-09 16:06:52', 'raja', 'https://terena.org/sp', '172.16.21.132', '', ''),
(375, '_5806383969258744600', '2020-06-10 10:48:07', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(376, '_-7476247209024122885', '2020-06-12 10:19:11', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(377, '_9026771198995593938', '2020-06-16 10:53:02', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(378, '_-508370690895049659', '2020-06-17 12:40:32', 'pallab', 'https://sp.tshhosting.com/shibboleth', '172.16.21.133', '', ''),
(379, '_7cad113c5892d3d3b31f328c88abc51dcb5e2bbc22', '1970-01-01 05:30:00', 'raja', 'https://terena.org/sp', '172.16.21.239', '', ''),
(393, '_be7c4c9df3577aeedc926a89950ba34a', '2020-09-25 18:03:53', 'Gviswanath', 'http://shibboleth.ebscohost.com', 'true183.82.159.15', '', ''),
(394, '_db3b880452b7fae5d0bd08c61709d5dd', '2020-09-25 18:04:22', 'Gviswanath', 'http://shibboleth.ebscohost.com', 'true183.82.159.15', '', ''),
(398, '_14e3a3e7d556f4a63f5308165e5f25ff', '2020-09-25 12:37:39', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', '');
INSERT INTO `userstats` (`id`, `session_id`, `log_date`, `user`, `sp`, `ip_address`, `idp`, `line_number`) VALUES
(399, '_34a357fa64c7bb0da0bab04ead0a9572', '2020-09-25 16:36:08', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', ''),
(400, '_998797342062d0c45bdbda075db4b543', '2020-09-25 16:37:09', 'itrail', 'https://shibboleth2sp.tf.semcs.net/shibboleth', 'true183.83.135.137', '', ''),
(401, '_65a455db9e11dcf962ce26a8a6d650a2', '2020-09-25 16:39:04', 'itrail', 'https://shibboleth2sp.tf.semcs.net/shibboleth', 'true183.83.135.137', '', ''),
(402, '_c212d8bf754cdddc6f13702aa8e0fea9', '2020-09-25 16:39:27', 'itrail', 'https://shibbolethsp.jstor.org/shibboleth', 'true183.83.135.137', '', ''),
(403, '_9ed1225b66519b5ae127ef01475eda2c', '2020-09-25 16:39:54', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', ''),
(404, '_4c52d4c2fd2cadb91d0e5ea603f51b95', '2020-09-25 16:44:30', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', ''),
(405, '_b236dfe69539ff32e749e0b40c952f0a', '2020-09-25 16:44:43', 'itrail', 'https://shibboleth2sp.tf.semcs.net/shibboleth', 'true183.83.135.137', '', ''),
(406, '_d4fdfa7f454df8505dd5e52eee89b098', '2020-09-25 16:44:59', 'itrail', 'https://shibboleth2sp.tf.semcs.net/shibboleth', 'true183.83.135.137', '', ''),
(407, '_e8392e3cc1a511accad981332f4e9541', '2020-09-25 16:45:08', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', ''),
(408, '_5212dd0ac49e636c0ac52dc2fca1ebef', '2020-09-25 16:45:23', 'itrail', 'https://shibbolethsp.jstor.org/shibboleth', 'true183.83.135.137', '', ''),
(409, '_c3cc0ba626e9bb27985bb0602616e290', '2020-09-25 16:45:40', 'itrail', 'https://shibboleth2sp.tf.semcs.net/shibboleth', 'true183.83.135.137', '', ''),
(410, '_61116c0cd36bdf7465458faa2f670102', '2020-09-25 16:45:49', 'itrail', 'http://shibboleth.ebscohost.com', 'true183.83.135.137', '', ''),
(411, '_1be201980c6f82294f84eceb03b04b2d', '2020-09-25 18:57:09', 'itrail', 'https://shibbolethsp.jstor.org/shibboleth', 'true43.241.193.245', '', ''),
(412, '_7cf5de55cf099ddb97cebe6ce52c0adf', '2020-09-25 18:58:10', 'itrail', 'http://shibboleth.ebscohost.com', 'true43.241.193.245', '', ''),
(413, '_c87208e8c55474aac781261566f21019', '2020-09-25 19:14:58', 'itrail', 'http://shibboleth.ebscohost.com', 'true43.241.193.245', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `spdetails`
--
ALTER TABLE `spdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stateinfo`
--
ALTER TABLE `stateinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userstats`
--
ALTER TABLE `userstats`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `spdetails`
--
ALTER TABLE `spdetails`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `stateinfo`
--
ALTER TABLE `stateinfo`
  MODIFY `id` bigint(65) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `stats`
--
ALTER TABLE `stats`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userstats`
--
ALTER TABLE `userstats`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=414;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
