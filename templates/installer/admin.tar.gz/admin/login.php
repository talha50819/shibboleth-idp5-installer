<!DOCTYPE html>


 <html lang="en"> 
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
<title>Login </title>
<script type="text/javascript" src="assets/js/login.js"></script>
<link rel="stylesheet" href="assets/css/login.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
</head>

<body class="align">
<div class="box">

  <div class="grid">
         <?php 
         if ( isset($_GET['error']) && $_GET['error'] == 1 )
        {?>
         <div class="alert alert-danger msg-error">                

        <?php echo $_GET['msg']?> 
        <i class = "fa fa-close btn-close"></i>
        </div> 
                                                     
        <?php  }
      ?>

    <form action="validatelogin.php" class="form login" onsubmit="return checkForm(this);" method="POST" id="validation"> 
 <img src="../assets/images/logo.png"/ class="login_logo">
      <div class="form__field">
        <label for="login__username"><svg class="icon">
            <use xlink:href="#icon-user"></use>
          </svg><span class="hidden">Username</span></label>
        <input autocomplete="username" id="login__username" type="text" name="username" class="form__input" placeholder="Username" required>
      </div>

      <div class="form__field">
        <label for="login__password"><svg class="icon">
            <use xlink:href="#icon-lock"></use>
          </svg><span class="hidden">Password</span></label>
        <input id="login__password" type="password" name="password" class="form__input" placeholder="Password" required>
      </div>
<div class="form-group">
<div class="input-icon">
<img style="width: 80%;height: 40px;" id="captcha" src="captcha.php" alt="CAPTCHA">
<img style="width: 15%; padding:7px;"  id="reload" src="assets/refresh.png">
</div>
</div>


<div class="form-group">
<div class="input-icon">
<i class="icon-lock" >
</i>
<input type="text" name="captcha" id="verification" class="form-control" placeholder="Solve verification" data-rule-required="true" data-msg-required="Please enter Captcha.">
</div>
</div>

      <div class="form__field">
        <!-- <input type="submit" value="Sign In"> -->
<button type="submit" name="submit" class="submit btn btn-primary pull-right"> Sign In <i class="fa fa-sign-in 2x"></i>
        
      </div>

    </form>


  </div>

  <svg xmlns="http://www.w3.org/2000/svg" class="icons">
    <symbol id="icon-arrow-right" viewBox="0 0 1792 1792">
      <path d="M1600 960q0 54-37 91l-651 651q-39 37-91 37-51 0-90-37l-75-75q-38-38-38-91t38-91l293-293H245q-52 0-84.5-37.5T128 1024V896q0-53 32.5-90.5T245 768h704L656 474q-38-36-38-90t38-90l75-75q38-38 90-38 53 0 91 38l651 651q37 35 37 90z" />
    </symbol>
    <symbol id="icon-lock" viewBox="0 0 1792 1792">
      <path d="M640 768h512V576q0-106-75-181t-181-75-181 75-75 181v192zm832 96v576q0 40-28 68t-68 28H416q-40 0-68-28t-28-68V864q0-40 28-68t68-28h32V576q0-184 132-316t316-132 316 132 132 316v192h32q40 0 68 28t28 68z" />
    </symbol>
    <symbol id="icon-user" viewBox="0 0 1792 1792">
      <path d="M1600 1405q0 120-73 189.5t-194 69.5H459q-121 0-194-69.5T192 1405q0-53 3.5-103.5t14-109T236 1084t43-97.5 62-81 85.5-53.5T538 832q9 0 42 21.5t74.5 48 108 48T896 971t133.5-21.5 108-48 74.5-48 42-21.5q61 0 111.5 20t85.5 53.5 62 81 43 97.5 26.5 108.5 14 109 3.5 103.5zm-320-893q0 159-112.5 271.5T896 896 624.5 783.5 512 512t112.5-271.5T896 128t271.5 112.5T1280 512z" />
    </symbol>
  </svg>

</body>

</html>
<script>
  $(document).ready(function(){
    $('#captcha').attr('src', 'captcha.php?'+(new Date()).getTime());

    $('#reload').click(function(){
      $('#captcha').attr('src', 'captcha.php?'+(new Date()).getTime());
    });
  });
$(".msg-error .btn-close").click(function() {
  $(this).closest('.msg-error').hide();
});
</script>