<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
   ?>
<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
</head>
<body >
<div id="main">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<div class="w3-container " >
  <div class=" w3-display-middle w3-card-4 w3-border mobcss" style="box-shadow: 10px 10px 250px #00ADEF;">
    
    <div class="w3-container" >

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="w3-panel w3-animate-zoom w3-green w3-display-container" id="success_msg" >
      <span onclick="this.parentElement.style.display='none'"
      class="w3-button w3-green w3-large w3-display-topright">&times;</span>
      <h4><?php echo $_SESSION["msg"];?></h4>
    </div>
    <?php } ?>
    </div>



  </div>
  
</div>

<h1>Home</h1>
</div>

<div class="content">
<form class="form-vertical login-form" action="logics.php"  method="POST">
<h3 class="form-title">Add Publisher</h3>
<div class="alert fade in alert-danger" style="display: none;">
<i class="icon-remove close" data-dismiss="alert">
</i> Enter any publisher name . </div>
<div class="form-group">
<div class="input-icon">
<i class="icon-user">
</i>
<input type="text" class="form-control" placeholder="Enter Publisher Name" id="pubname" name="pubname" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter Enter Publisher Name."/>
</div>
</div>

<div class="form-group">
<div class="input-icon">
<i class="fa fa-globe">
</i>
<input type="text" class="form-control" placeholder="Enter Publisher's WAYFLess Url/Link " id="publink" name="publink" autofocus="autofocus" data-rule-required="true" data-msg-required="Enter Publisher's WAYFLess Url/Link"/>
</div>
</div>

<div class="form-group">
<div class="input-icon">


<select id="category" name="category" class="form-control" data-msg-required="Please Select Category.">
    <option value="cat" disabled selected>Select Category</option>
    <option value="book">E-Book</option>
    <option value="database">E-Database</option>
    <option value="journal">E-Journal</option>
  </select>
<!-- <input type="text" class="form-control" placeholder="Enter Publisher Entity ID/Link " id="publink" name="publink" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter Enter Publisher URL."/> -->
</div>
</div>
<div class="form-actions">

<button type="submit" name="addnew" class="submit btn btn-primary pull-right"> Submit 
</button>
</div>
</form>

</div>`
</body>
</html>







