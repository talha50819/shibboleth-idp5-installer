<?php
  include 'dbconfig.php';
  include 'menu.php';
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
   ?>



<!-- <div id="main"> -->

<!-- <div class="w3-container " >

    
    <div class="w3-container" >




   

  </div>
  
</div>
 -->
<!-- <h1 class="headings">Change Password</h1> -->
</div>

<div class="box">
<div class="msg-container" id="msg">

    <?php if(isset($_SESSION["msg"])){ ?>
    <div class="msg-box" id="success_msg" >
      <h4><?php echo $_SESSION["msg"];?><i class = "fa fa-close" style="float: right" onclick="closemsg()"></i></h4>
        <?php unset($_SESSION["msg"]) ?>
    </div>
    <?php } ?>
    </div>
  
<div class="content">
    
<!-- <div class="tab">
<button class="tablinks active" onclick="openCity(event, 'chpwd')">Change Password</button>

       <button class="tablinks" style="float: right;"><a href="logout.php"><i class="fa fa-sign-out" style="font-size: 24px;color: black;" ></i></a></button>
     <button class="tablinks" style="float: right;">  <a href="index.php"><i class="fa fa-home" style="font-size: 24px;color: black;" ></i></a></button>
     <div class="dropadown" style="float: right;">
  <button onclick="myFunction()" class="dropabtn"><i class="fa fa-user"></i>&nbsp;Admin&nbsp;<i class="fa fa-caret-down"></i></button>
  <div id="mydropadown" class="dropadown-content"> -->
     <!-- <a href = "changepassword.php" style="font-size: 16px;color: black;" ><i class="fa fa-key" ></i>Change Password</a>
   <a href="logout.php" style="font-size: 16px;color: black;" ><i class="fa fa-sign-out" ></i>Logout</a>
 
  </div>
</div>

</div> -->
<div id="chpwd" class="tabcontent" style="display:block">
  <div class="content">
<div class="single">

  <h3>Change Password</h3>
  <hr>
  
<form class="form-vertical login-form" action="logics.php"  method="POST">

<div class="alert fade in alert-danger" style="display: none;">
<i class="icon-remove close" data-dismiss="alert">
</i> Enter any username and password. </div>
<div class="form-group">
<div class="input-icon">
<i class="icon-user">
</i>
<input type="password" class="form-control" placeholder="Enter old password" id="oldpass" name="oldpass" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter your old password."/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="icon-lock">
</i>
<input type="password" class="form-control" placeholder="Enter new password" id="newpass" name="newpass" pattern="^([a-zA-Z0-9@!$*#]{5,15})$" class="form-control" title="it should contain  minimun 5 characters" data-rule-required="true" data-msg-required="it should contain  minimun 5 characters"/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="icon-lock">
</i>
<input type="password"  class="form-control" placeholder="Retype password" id="renewpass" name="renewpass" pattern="^([a-zA-Z0-9@!$*#]{5,15})$" data-rule-required="true" />
</div>
</div>


<button type="submit" name="changepass" class="add"> Submit 
</button>

</form>
  </div>
</div>
</div>





</div>





</div>











